#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define STATE_NEW 0
#define STATE_READY 1
#define STATE_RUNNING 2
#define STATE_WAITING 3
#define STATE_TERMINATED 4

typedef pthread_t tid_t;

typedef struct thread {
    tid_t tid;
    unsigned int state;
    int *waiting_for;
    unsigned int priority;
}Thread, *PThread;

typedef struct list {
    struct list *next;
    struct list *last;
    Thread thread;
}List, *PList;

PList addT(PList head, Thread thread);
PThread getT(PList head, tid_t tid);
PList addT_Prio(PList head, Thread thread);
int removeT(PList head, Thread thread);
void freeList(PList head);

PList addT(PList head, Thread thread)
{
    if (head == NULL) {
        head = malloc(sizeof(List));
        head->thread = thread;
        head->next = NULL;
        head->last = head;
    } else {
        PList node = malloc(sizeof(List));
        node->thread = thread;
        node->next = head->last->next;
        node->last = node;
        head->last->next = node;
        head->last = node;
    }
    return head;
}

PList addT_Prio(PList head, Thread thread)
{
    if (head == NULL) {
        head = addT(head, thread);
        head->next = head;
        return head;
    } else {
        PList copy = head, prev;
        if (head->thread.priority < thread.priority) {
            PList node = malloc(sizeof(List));
            node->thread = thread;
            node->next = head;
            //printf("%d\n", head->last);
            head->last->next = node;
            node->last = head->last;
            head = node;
            return head;
        }
        while (copy->thread.priority >= thread.priority) {
            prev = copy;
            copy = copy->next;
            if(copy == head) {
                break;
            }
        }
        PList node = malloc(sizeof(List));
        node->thread = thread;
        prev->next = node;
        node->next = copy;
        if (prev == head->last) {
            head->last = node;
        }
        node->last = head->last;
        return head;
    }
}

void printList(PList head)
{
    if (head == NULL) {
        printf("NULL\n");
        return;
    }
    PList copy = head;
    while (copy->next != head) {
        //printf("PRint Last thread is %d\n", head->last->thread.priority);
        printf("%u ", copy->thread.priority);
        copy = copy->next;
    }
    printf("%u\n", copy->thread.priority);
}

PList removeHead(PList head)
{
    if (head == NULL) {
        return NULL;
    }
    if (head->last == head) {
        free(head);
        return NULL;
    } else { 
        printf("Last thread is %d\n", head->last->thread.priority);
        PList copy = head, last = head->last;
        last->next = head->next;
        head = last->next;
        head->last = last;
        free(copy);
        return head;
    }
}

PThread getT(PList head, tid_t tid)
{
    PList copy = head;
    while (head != NULL) {
        if (tid == head->thread.tid) {
            return &(head->thread);
        }
        head = head->next;
        if(head == copy) {
            head = NULL;
        }
    }
    return NULL;
}

void freeList(PList head)
{
    PList copy = head, tmp, last = head->last;
    do {
        tmp = copy->next;
        free(copy);
        copy = tmp;
    } while (copy != last && copy != NULL);

    if(head != last)
        free(last);
}

int main(void) {
    PList list = NULL;
    int mat[10] = {5, 12, 1 ,54, 1 , 5, 3, 4, 5, 0};
    for (int i = 0; i < 10; i++) {
        Thread t;
        t.priority = mat[i];
        t.tid = i;
        list = addT_Prio(list, t);
    }
    // printf("%d ", getT(list, inp)->priority);
    printList(list);
    printf("%d\n", list->last->thread.priority);
    list = removeHead(list);
    printf("%d\n", list->last->thread.priority);
    printList(list);
    list = removeHead(list);
    printf("%d\n", list->last->thread.priority);
    printList(list);
}