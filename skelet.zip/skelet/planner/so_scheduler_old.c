// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <pthread.h>
// #include <semaphore.h>

// #include "../util/so_scheduler.h"
// #include "../util/so_list.h"

// typedef struct planner {
//     PList threads;
//     PList ready_threads;
//     unsigned int thread_count;
//     unsigned int thread_time;
//     unsigned int event_nr;
// }Planner, *PPlanner;

// typedef struct param { 
//     unsigned int prio;
//     so_handler *func;
// }Param, *PParam;

// static PPlanner so_planner;
// static int init = 0;
// static int cnt = 0;
// static int a = -10;
// static sem_t sem;

// void checkTime();

void scheduler()
{
    if (so_planner->ready_threads == NULL) {
        return;
    }
    PThread pt = getT(so_planner->ready_threads, pthread_self());
    if (pt == NULL) {
        return;
    }
    printf("Threadul cu prioritatea %d a verificat, time is %d, lista era ->", pt->priority, pt->time_left);
    printList(so_planner->ready_threads);
    printf("prios: my %d all %d\n", pt->priority, so_planner->ready_threads->thread.priority);
    printf("tid: my %ld all %ld\n", pt->tid, so_planner->ready_threads->thread.tid);
    if(pt->tid == so_planner->ready_threads->thread.tid) {
        sem_post(&(pt->sem));
        printf("Posted me (%ld)\n", pt->tid);
    }
    sem_wait(&(pt->sem));
}

// void decreaseTime()
// {
//     PThread pt = getT(so_planner->ready_threads, pthread_self());
//     if (pt != NULL) {
//         pt->time_left--; 
//         printf("Thead nr: %ld -> TIme left: %d\n", pt->tid, pt->time_left);
//     }
// }

// void checkTime()
// {
//     PThread pt = getT(so_planner->ready_threads, pthread_self());
//     PList curr = getL(so_planner->ready_threads, pthread_self());
//     if (pt == NULL)
//         return;
//     //printf("Thead nr: %ld -> TIme left: %d\n", pt->tid, pt->time_left);
//     if (pt->time_left <= 0) {
//         pt->time_left = so_planner->thread_time;
//         sem_getvalue(&(pt->sem), &a);
//         printf("Sem for %ld is %d\n", pt->tid, a);
//         printf("New thread should be %ld\n", curr->next->thread.tid);
//         so_planner->ready_threads = removeHead(so_planner->ready_threads);
//         so_planner->ready_threads = addT_Prio(so_planner->ready_threads, *pt);
//         printList(so_planner->ready_threads);
//         sem_post(&(so_planner->ready_threads->thread.sem));
//         sem_getvalue(&(so_planner->ready_threads->thread.sem), &a);
//         printf("For thread %ld sem is %d\n", so_planner->ready_threads->thread.tid, a);
//         sem_getvalue(&(pt->sem), &a);
//         printf("I (%ld) will wait,  my sem is: %d\n", pt->tid, a);
//         printf("I signaled %ld to wake up\n", so_planner->ready_threads->thread.tid);
//         sem_wait(&(pt->sem));
//         sem_getvalue(&(pt->sem), &a);
//         printf("I (%ld) will wait,  my sem is: %d\n", pt->tid, a);
//         printf("Came back, curr thread is %ld\n", pt->tid);
//     }
// }

// void *start_thread(void *data) {
//     Param *p = data;
//     Thread thread;
//     thread.tid = pthread_self();;
//     thread.priority = p->prio;;
//     thread.state = 0;
//     thread.waiting_for = NULL;
//     thread.time_left = so_planner->thread_time;
//     sem_init(&(thread.sem), 0, 0);
//     so_planner->threads = addT(so_planner->threads, thread);
//     so_planner->ready_threads = addT_Prio(so_planner->ready_threads, thread);
//     so_planner->thread_count++;
//     scheduler();
//     cnt++;
//     PThread pt = getT(so_planner->ready_threads, pthread_self());
//     if (pt != NULL)
//         printf("Incepere thread %ld cu prio %d -> lista era:", pt->tid, pt->priority);
//     printList(so_planner->ready_threads);
//     p->func(p->prio);
//     free(data);
//     if (so_planner != NULL)
//         so_planner->ready_threads = removeHead(so_planner->ready_threads);
//     so_planner->thread_count--;
//     if (so_planner->thread_count <= 0)
//         sem_post(&sem);
//     if (so_planner->ready_threads != NULL)
//         sem_post(&(so_planner->ready_threads->thread.sem));
//     printf("Nr de threaduri :%d\n", so_planner->thread_count);
//     printf("IESIM din threadul %ld\n", pt->tid);
//     pthread_exit(NULL);
// }

// int so_init(unsigned int time_quantum, unsigned int io)
// {
//     if (so_planner == NULL) {
//         so_planner = malloc(sizeof(Planner));
//         so_planner->threads = NULL;
//         so_planner->ready_threads = NULL;
//         so_planner->thread_count = 0;
//     } else
//         return -1;

//     if (io > SO_MAX_NUM_EVENTS)
//         return -1;
//     else
//         so_planner->event_nr = io;

//     if (time_quantum == 0)
//         return -1;
//     else
//         so_planner->thread_time = time_quantum;
//     if (init == 0) {
//         init = 1;
//     }
//     sem_init(&sem, 0, 0);
//     return 0;
// }

// tid_t so_fork(so_handler *func, unsigned int priority)
// {
//     decreaseTime();
//     checkTime();
//     if (priority > SO_MAX_PRIO || func == NULL)
//         return INVALID_TID;
    
//     Thread thread;
//     tid_t tid;
//     Param *p = malloc(sizeof(Param));
//     p->func = func;
//     p->prio = priority;
//     int ret = pthread_create(&tid, NULL, start_thread , (void *) p);
//     if (ret == 0) {
//         // thread.tid = tid;
//         // thread.priority = priority;
//         // thread.state = 0;
//         // thread.waiting_for = NULL;
//         // thread.time_left = so_planner->thread_time;
//         // sem_init(&(thread.sem), 0, 0);
//         // so_planner->threads = addT(so_planner->threads, thread);
//         // so_planner->ready_threads = addT_Prio(so_planner->ready_threads, thread);
//         // so_planner->thread_count++;
//         return tid;
//     } else
//         return INVALID_TID;
// }

// int so_wait(unsigned int io)
// {
//     decreaseTime();
//     checkTime();
//     PThread crt = getT(so_planner->ready_threads, pthread_self());
//     *(crt->waiting_for) = io;
//     //make other checks
// }

// int so_signal(unsigned int io)
// {
//     decreaseTime();
//     checkTime();
//     PList crt;
//     int sum = 0;
//     for (crt = so_planner->threads; crt != NULL; crt = crt->next) {
//         if (io == *(crt->thread.waiting_for)){
//             sum++;
//             //add back in queue
//             //check if it's first in queue
//             //unlock sem at some point
//         }
//     }
// }

// void so_exec(void)
// {
//     decreaseTime();
//     checkTime();
// }

// void so_end(void)
// {
//     sem_wait(&sem);
//     if(so_planner != NULL) {
//         //printList(so_planner->ready_threads);
//         if(so_planner->threads != NULL) {
//             PList myhd = so_planner->threads;
//                 while (myhd) {
//                     printf("AM AJUNS CA PROSTUL AICI!\n");
//                     pthread_join(myhd->thread.tid, NULL);
//                     myhd = myhd->next;
//                 }
//             freeList(so_planner->threads);
//             so_planner->threads = NULL;
//         }
//         if (so_planner->ready_threads) {
//             freeList(so_planner->ready_threads);
//         }
//         free(so_planner);
//     }
//     if (init == 1) {
//         init = 0;
//     }
//     so_planner = NULL;
//     sem_destroy(&sem);
// }