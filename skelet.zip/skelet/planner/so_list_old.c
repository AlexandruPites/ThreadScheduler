#include <stdio.h>
#include <stdlib.h>

#include "../util/so_list.h"

PList addT(PList head, Thread thread)
{
    if (head == NULL) {
        head = malloc(sizeof(List));
        head->thread = thread;
        head->next = NULL;
        head->last = head;
    } else {
        PList node = malloc(sizeof(List));
        node->thread = thread;
        node->next = head->last->next;
        head->last->next = node;
        head->last = node;
    }
    return head;
}

PList addT_Prio(PList head, Thread thread)
{
    printList(head);
    if (head == NULL) {
        head = addT(head, thread);
        head->next = head;
        return head;
    } else {
        PList copy = head, prev;
        if (head->thread.priority < thread.priority) {
            PList node = malloc(sizeof(List));
            node->thread = thread;
            node->next = head;
            head->last->next = node;
            node->last = head->last;
            head = node;
            return head;
        }
        while (copy->thread.priority >= thread.priority) {
            prev = copy;
            copy = copy->next;
            if(copy == head) {
                break;
            }
        }
        PList node = malloc(sizeof(List));
        node->thread = thread;
        prev->next = node;
        node->next = copy;
        if (prev == head->last) {
            head->last = node;
        }
        return head;
    }
}

void printList(PList head)
{
    if (head == NULL) {
        printf("NULL\n");
        return;
    }
    PList copy = head;
    while (copy->next != head) {
        printf("%ld : %u ", copy->thread.tid, copy->thread.priority);
        copy = copy->next;
    }
    printf("%ld : %u\n", copy->thread.tid, copy->thread.priority);
}

PList removeHead(PList head)
{
    printList(head);
    if (head == NULL) {
        return NULL;
    }
    if (head->last == head) {
        //sem_destroy(&(head->thread.sem));
        return NULL;
    } else {
        PList copy = head, last = head->last;
        last->next = head->next;
        head = last->next;
        head->last = last;
        sem_destroy(&(copy->thread.sem));
        return head;
    }
}

PThread getT(PList head, tid_t tid)
{
    PList copy = head;
    while (copy != NULL) {
        if (tid == copy->thread.tid) {
            return &(copy->thread);
        }
        copy = copy->next;
        if(copy == head) {
            copy = NULL;
        }
    }
    return NULL;
}

PList getL(PList head, tid_t tid)
{
    PList copy = head;
    while (copy != NULL) {
        if (tid == copy->thread.tid) {
            return copy;
        }
        copy = copy->next;
        if(head == copy) {
            copy = NULL;
        }
    }
    return NULL;
}

void freeList(PList head)
{
    PList copy = head, tmp, last = head->last;
    do {
        tmp = copy->next;
        free(copy);
        copy = tmp;
    } while (copy != last && copy != NULL);

    if(head != last)
        free(last);
}