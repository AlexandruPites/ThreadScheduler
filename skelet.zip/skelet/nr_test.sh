#!/bin/bash
export LD_LIBRARY_PATH=.
cd ../checker-lin
./_test/run_test $1